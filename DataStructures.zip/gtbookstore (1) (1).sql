-- Improved GT Bookstore Database Schema

-- Drop database if it exists and create a new one
DROP DATABASE IF EXISTS gtbookstore;
CREATE DATABASE gtbookstore;
USE gtbookstore;

-- Create books table with improved schema
CREATE TABLE `books` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `isbn` varchar(20) DEFAULT NULL COMMENT 'International Standard Book Number',
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `stock_quantity` int(11) NOT NULL DEFAULT 0,
  `category_id` int(11) DEFAULT NULL,
  `publisher` varchar(255) DEFAULT NULL,
  `publication_date` date DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `image` varchar(255) DEFAULT 'default_book.jpg',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `isbn_unique` (`isbn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create book categories table
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `category_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Add foreign key constraint to books table
ALTER TABLE `books`
  ADD CONSTRAINT `fk_book_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL;

-- Create users table with improved security
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL COMMENT 'Securely hashed password',
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `role` enum('customer','admin','staff') NOT NULL DEFAULT 'customer',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `last_login` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username_unique` (`username`),
  UNIQUE KEY `email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create orders table
CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `order_date` datetime NOT NULL DEFAULT current_timestamp(),
  `total_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` enum('pending','processing','shipped','delivered','cancelled') NOT NULL DEFAULT 'pending',
  `shipping_address` text NOT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `tracking_number` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_orders` (`user_id`),
  CONSTRAINT `fk_order_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create order items table
CREATE TABLE `order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `price` decimal(10,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_order_items` (`order_id`),
  KEY `idx_book_orders` (`book_id`),
  CONSTRAINT `fk_orderitem_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_orderitem_book` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create reviews table
CREATE TABLE `reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `book_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `rating` int(1) NOT NULL CHECK (rating BETWEEN 1 AND 5),
  `comment` text DEFAULT NULL,
  `is_approved` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_book_reviews` (`book_id`),
  KEY `idx_user_reviews` (`user_id`),
  CONSTRAINT `fk_review_book` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_review_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Improved contacts table
CREATE TABLE `contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `message` text NOT NULL,
  `status` enum('new','read','replied','closed') NOT NULL DEFAULT 'new',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create wishlist table
CREATE TABLE `wishlists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `added_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_wishlist_item` (`user_id`,`book_id`),
  KEY `idx_book_wishlists` (`book_id`),
  CONSTRAINT `fk_wishlist_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wishlist_book` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create shopping cart table
CREATE TABLE `cart_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `added_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_cart_item` (`user_id`,`book_id`),
  KEY `idx_book_carts` (`book_id`),
  CONSTRAINT `fk_cart_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cart_book` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert sample data for categories
INSERT INTO `categories` (`name`, `description`) VALUES
('Fiction', 'Novels and fictional stories'),
('Philosophy', 'Books about philosophical thinking and ideas'),
('Children', 'Books suitable for children and young readers'),
('Classics', 'Classic literature that has stood the test of time');

-- Insert sample book data with improved details
INSERT INTO `books` (`isbn`, `title`, `author`, `description`, `price`, `stock_quantity`, `category_id`, `publisher`, `publication_date`, `is_active`, `image`) VALUES
('9780812968255', 'Meditations', 'Marcus Aurelius', 'Meditations is a series of personal writings by Marcus Aurelius, Roman Emperor 161–180 CE, setting forth his ideas on Stoic philosophy. Marcus Aurelius wrote the 12 books of the Meditations in Koine Greek as a source for his own guidance and self-improvement.', 12.99, 25, 2, 'Modern Library', '2003-05-06', 1, 'book1.jpg'),
('9781419741968', 'Old School (Diary of a Wimpy Kid #10)', 'Jeff Kinney', 'In Old School, Book 10 of the Diary of a Wimpy Kid series from #1 international bestselling author Jeff Kinney, life was better in the old days. Or was it? That\'s the question Greg Heffley is asking as his town voluntarily unplugs and goes electronics-free.', 13.95, 40, 3, 'Amulet Books', '2015-11-03', 1, 'book2.jpg'),
('9780141324920', 'The Last Straw (Diary of a Wimpy Kid #3)', 'Jeff Kinney', 'The third book in the #1 New York Times best-selling series from Jeff Kinney, The Last Straw is sure to please young readers. Greg Heffley makes a New Year\'s resolution to help others improve, but his brand of truthful advice doesn\'t go over well.', 13.95, 35, 3, 'Puffin Books', '2009-01-13', 1, 'book3.jpg'),
('9780810987586', 'Diary of a Wimpy Kid', 'Jeff Kinney', 'I\'ll be famous one day, but for now I\'m stuck in middle school with a bunch of morons. Being a kid can really stink. And no one knows this better than Greg Heffley, who finds himself thrust into middle school, where undersized weaklings share the hallways with kids who are taller, meaner, and already shaving.', 13.95, 50, 3, 'Amulet Books', '2007-04-01', 1, 'book4.jpg'),
('9781503280786', 'Moby Dick: Or The White Whale', 'Herman Melville', 'Moby-Dick; or, The Whale is an 1851 novel by American writer Herman Melville. The book is the sailor Ishmael\'s narrative of the maniacal quest of Ahab, captain of the whaling ship Pequod, for vengeance against Moby Dick, the giant white sperm whale that bit off his leg at the knee.', 14.50, 20, 4, 'CreateSpace Independent Publishing', '2014-11-10', 1, 'book5.jpg'),
('9780316310277', 'The Cruel Prince (The Folk of the Air, 1)', 'Holly Black', 'Of course I want to be like them. They\'re beautiful as blades forged in some divine fire. They will live forever. And Cardan is even more beautiful than the rest. I hate him more than all the others. I hate him so much that sometimes when I look at him, I can hardly breathe.', 18.99, 30, 1, 'Little, Brown Books for Young Readers', '2018-01-02', 1, 'book6.jpg'),
('9780743233835', 'The Emperor\'s Handbook: A New Translation of The Meditations', 'Marcus Aurelius', 'A powerful and accessible translation of Marcus Aurelius\'s Meditations, an essential book on character, leadership, and how to live a fulfilling life. Marcus Aurelius ruled the Roman Empire at its height, yet he remained untainted by the incalculable wealth and absolute power that had corrupted many of his predecessors.', 16.99, 15, 2, 'Scribner', '2002-11-26', 1, 'book7.jpg'),
('9780140449242', 'The Brothers Karamazov', 'Fyodor Dostoyevsky', 'Fyodor Dostoyevsky\'s powerful meditation on faith, meaning and morality, The Brothers Karamazov is translated with an introduction and notes by David McDuff in Penguin Classics. When brutal landowner Fyodor Karamazov is murdered, the lives of his sons are changed forever.', 19.99, 10, 4, 'Penguin Classics', '2003-02-27', 1, 'book8.jpg');

-- Insert a sample admin user (password would be properly hashed in a real application)
-- In a real application, you would use a secure hashing function like bcrypt, not store raw passwords
INSERT INTO `users` (`username`, `email`, `password_hash`, `firstname`, `lastname`, `role`, `is_active`) VALUES
('admin', 'admin@gtbookstore.com', '$2y$10$CGuPMbOfiRuVOFPQvBzPqOD9vYN4pJIVGkL4XeEwZRLRmXQdQVpTC', 'System', 'Administrator', 'admin', 1),
('user', 'user@gmail.com', '$2y$10$wHlLRKBWgbKCnL.5kgkYheuTlhR9UzHd9AeVQuLkB.56XKv5pzRxK', 'John', 'Doe', 'customer', 1);

-- Insert sample contact message
INSERT INTO `contacts` (`firstname`, `lastname`, `email`, `subject`, `message`, `status`) VALUES
('Gilbert', 'Tekli', 'gt@gmail.com', 'Website Feedback', 'I love your website! You deserve an A!', 'new');